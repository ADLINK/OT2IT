
extern "C" {
#include <string.h>
}

#include "ethernet_phy.h"
#include "rmii.h"
